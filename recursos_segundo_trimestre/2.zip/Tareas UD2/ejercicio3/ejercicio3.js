let a;
let b;
let c;
let continuar = true;

console.log(isNaN(""));//false
console.log(isNaN("g"));//true
do{
    document.write("");
    b = pedirNumero("Ingresa la longitod del cateto1:");
    c = pedirNumero("Ingresa la longitud del cateto2:");
    a = Math.sqrt(Math.pow(b,2)+Math.pow(c,2));
    document.write(`<p>La hipotenusa del cateto1 = ${b}cm y el cateto2 = ${c}cm es ${a.toFixed(2)}cm</p>`);
    continuar = confirm("Pulse OK si desea continuar");

}while(continuar)

function pedirNumero(frase){
    let esNumero = true;
    let n;
    do{
        n = prompt(frase);
        
        esNumero = n == null? false :(n==""?false : !isNaN(n));
        if(!esNumero ){
            alert("ERROR. Debes introducir un número entero.")
        }else{
            esNumero = true;
        }
    }while(!esNumero);
    
    return parseInt(n);
}