function generarDia(){
    //genéro un númeo aleatorio entre 0 y 30;
    let dia = Math.floor(Math.random()*30)+1;

    //escojo la fecha actual para sacar el mes y el año.
    let fechaActual = new Date();

    //creo una nueva fecha con el mes y año actuales + el dia generado de forma aleatoria
    let fecha = new Date(fechaActual.getFullYear(),fechaActual.getMonth(), dia);


    document.write(`<p>La fecha de apertura de la tarea es ${fecha.toDateString()}</p>`);

    //sumo 30 dias a la fecha
    fecha.setDate(fecha.getDate()+30);
    document.write(`<p>La fehca de entrega es: ${fecha.toDateString()}</p>`);
}
generarDia();