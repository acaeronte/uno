let nuevaVentana;

//esta variable controla que solo haya una ventana
let ventanaExiste = false;
function abrirVentana(){
    if(!ventanaExiste){
        nuevaVentana = window.open("ventanaNueva.html", "", "height = 200, width=200");
        nuevaVentana.document.write("La ventana es de 200x200 píxeles");
        ventanaExiste = true;
    }
    
}
function redimensionarVentana(){
if(ventanaExiste){
    nuevaVentana.resizeTo(600, 600);
    nuevaVentana.document.body.innerHTML = "";
    nuevaVentana.document.write("Ventana redimensionada a 600x600 píxeles");
}
}
function moverVentana(){
    if(ventanaExiste){
    let x = screen.width;
    let y = screen.height;
    nuevaVentana.moveTo(x,y/2);
    }
}
function cerrarVentana(){
    if(ventanaExiste)
    nuevaVentana.close();

    ventanaExiste = false;
    
}