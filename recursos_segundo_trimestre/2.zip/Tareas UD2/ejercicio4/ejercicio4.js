//contraseña fuerte: 1 minuscula, 2 mayusculas, 1 numero, 2 no alfanumericos
//ASCII mayusculas -> 65 - 90
//ASCII minusculas -> 97 - 122
//ASCII numeros -> 48 - 57
// lo demás son caracteres X

let password = prompt("Introduce una contraseña:")

//los booleanos controlan que se cumplan las condiciones de contraseña segura.
let tieneMayus = false;
let contMayus = 0;
let tieneMinus = false;
let tieneNum = false;
let tieneOtro = false;
let contOtro = 0;

for(var x = 0; x<password.length; x++){
    //verifico que el caracer es una mayúscula
    let caracter = password.charAt(x).charCodeAt(0);
    if(caracter > 65 && caracter <90){
        ++contMayus;
        if(contMayus>=2){
            //cuando haya acumulado 2 mayusculas, habrá alcanzado los requisitos mínimos de mayusculas
            tieneMayus = true;
        }
    //verifico que el caracter es una minuscula
    }else if(caracter > 97 && caracter<122){
        tieneMinus = true;
    //verifico que el caracter es un numero
    }else if(caracter > 48 && caracter < 57){
        tieneNum = true;
    //verifico que el caracter es cualquier otra cosa
    }else{
        ++contOtro;
        //cuando el contador haya acumulado 2, habrá alcanzado los requisitos mínimos de este apartado
        if(contOtro>=2){
            tieneOtro = true;
        }
    }
}
//confirmo que se han cumplido todos los requisitos.
if(tieneMayus && tieneMinus && tieneNum && tieneOtro){
    document.write("La contraseña es fuerte")
}else{
    document.write("La contraseña es débil");
}