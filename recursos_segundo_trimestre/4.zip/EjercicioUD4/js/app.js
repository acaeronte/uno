const aceptaCondiciones = false;
//clave cliente reCaptcha: 6LffVh0pAAAAAKHw1JEBdqO095onq7uoFny8U-BG
//clave servidor reCaptcha: 6LffVh0pAAAAAOZgxY0xMJkS7oZcKaU0UrHC3xHb
window.addEventListener("DOMContentLoaded", ()=>{
    document.getElementById("nombreApellidos").addEventListener("blur", formatearNombre);
    document.getElementById("anyoNacimiento").addEventListener("blur", verificarAnyoNacimiento);
    document.getElementById("usuario").addEventListener("blur", verificarUsuario);
    document.getElementById("password").addEventListener("blur", verificarPassword);
    document.getElementById("passwordRepeat").addEventListener("keyup", verificarPasswordRepeat);
    let chboxJornada = document.getElementsByName("tipoJornada");
    chboxJornada.forEach((elemento)=>{
        elemento.addEventListener("change", verificarJornada);
    });

    document.getElementById("aceptaCondiciones").addEventListener("change", verificarCondiciones);

    document.getElementById("formulario").addEventListener("submit", enviar);
})
const formatearNombre = () =>{
    let campoNombre = document.getElementById("nombreApellidos");
    let value = campoNombre.value.toUpperCase();
    campoNombre.value = value;
}

const verificarAnyoNacimiento = () =>{
    let err = document.getElementById("errAnyoNacimiento");
    let campoAnyoNacimiento = document.getElementById("anyoNacimiento");
    let expresion = /^(195[7-9]|19[6-9][0-9]|200[0-3])$/;
    if(!expresion.test(campoAnyoNacimiento.value)){
        //si falla, incluyo el mensaje de error
        err.innerHTML = "El año tiene que estar comprendido entre 1957 y 2003";
    }else{
        //si está bien, elimino el mensaje
        err.innerHTML="";
    }
}

const verificarUsuario = () =>{
    let err = document.getElementById("errUsuario");
    let campoUsuario = document.getElementById("usuario");
    let expresion = /^@[a-zA-ZñÑ_\-]{5,15}$/;
    if(!expresion.test(campoUsuario.value)){
        err.innerHTML = `
            El usuario debe:<br>
            - Comezar por "@"<br>
            - Mínimo 5 y máximo 15 caracteres<br>
            - Incluir un guión bajo "_" o medio "-" en cualquier posición despues del "@"
        `;
    }else{
        err.innerHTML = "";
    }
}

const verificarPassword = () =>{
    let err = document.getElementById("errPassword");
    let campoPassword = document.getElementById("password");
    let expresion = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s)(?=.*[\WS]).{5,16}$/;
    if(!expresion.test(campoPassword.value)){
        err.innerHTML=`
            La contraseña debe tener:<br>
            - Mínimo 8 caracteres y máximo 15.<br>
            - Al menos una letra mayúscula.<br>
            - Al menos una letra minúscula.<br>
            - Al menos un dígito.<br>
            - No espacios en blanco.<br>
            - Al menos 1 carácter especial.
        `;
    }else{
        err.innerHTML="";
    }
}

const verificarPasswordRepeat = () =>{
    //let err = document.getElementById("errPasswordRepeat");
    let campoPasswordRepeat = document.getElementById("passwordRepeat");
    let campoPassword = document.getElementById("password");
    if(campoPassword.value!=campoPasswordRepeat.value){
        campoPasswordRepeat.style.color = "red";
        //err.innerHTML = "La contraseña no coincide";
    }else{
        campoPasswordRepeat.style.color = "green";
        //err.innerHTML = "";
    }
}

const verificarJornada = () =>{
    let contador = 0;
    let errJornadas = document.getElementById("errJornada");
    let jornadas = document.getElementsByName("tipoJornada");
    jornadas.forEach((elemento)=>{
        if(elemento.checked){
            contador++;
        }
    })
    if(contador<1 || contador>3){
        errJornadas.innerHTML = "Debe elegirse mínimo una jornada y como máximo 3.";
    }else{
        errJornadas.innerHTML = "";
    }
}

const verificarCondiciones = () =>{
    let errCondiciones = document.getElementById("errCondiciones");
    let condiciones = document.getElementById("aceptaCondiciones");
    if(!condiciones.checked){
        errCondiciones.innerHTML = "Debe aceptar las condiciones de uso";
        condiciones = false;
    }else{
        errCondiciones.innerHTML = "";
        condiciones = true;
    }
}

const enviar = (event)=>{
    event.preventDefault();
    let contieneErrores = false;
    let errores = document.getElementsByClassName("error");
    let aErrores = Array.from(errores);

    let errorGeneral = document.getElementById("errGeneral");
    //Ejecutamos todas las funciones para comprobar todas los input.
    verificarAnyoNacimiento();
    verificarUsuario();
    verificarPassword();
    verificarPasswordRepeat();
    verificarJornada();
    verificarCondiciones();

    contieneErrores = aErrores.some((elemento)=>elemento.innerHTML !="");
    if(contieneErrores){
        errorGeneral.innerHTML = "Hay errores en el formulario, por favor revísalo e inténtalo de nuevo.";
    }else{
        errorGeneral.innerHTML = "";
        grecaptcha.ready(function() {
            grecaptcha.execute('6LffVh0pAAAAAKHw1JEBdqO095onq7uoFny8U-BG', {action: 'submit'}).then(function(token) {
                //recaptcha devuelve un token demostrando que el usuario ha completado la verificación con éxito.
                //Este token puede ser posteriormente enviado al servidor.
                //En este fragmento de código se incluirían las acciones a realizar para el envío al servidor.
                console.log(token);
            });
          });
          let fecha = new Date();

          let aCookies = document.cookie!=""?document.cookie.split(";"):[];
          let cookie;
          if(aCookies.length>0){
            //ya existe la cookie
            let valor = aCookies[0].split("="); //rescatamos la cookie
            let objeto = JSON.parse(valor[1]); //convertimos a objeto el valor json dentro del indice 1
            let contador = ++objeto.intentos; //aumentamos el numero de intentos en 1
            cookie = {
                intentos: contador,
                fecha:fecha.toLocaleDateString()
            };
          }else{
            //la cookie no existe, por lo que la creamos desde 0
            cookie = {
                intentos:1,
                fecha:fecha.toLocaleDateString()
            }
          }
          let json = JSON.stringify(cookie);
          //añadimos la cookie
          document.cookie = `Encuesta=${json};max-age=3600;secure`;
          console.log(document.cookie);

          //mostramos spinner
          let spinner = document.getElementById("spinner");
          let exito = document.getElementById("exito");
          spinner.style.display = "block";
          exito.style.textAlign="center";
          exito.innerHTML = "Enviando datos";


          let formulario = document.getElementById("formulario");
          let resultadoDiv = document.getElementById("resultado");
          let duracion = setTimeout(()=>{
            spinner.style.display= "none";
            exito.innerText = "";
            resultadoDiv.innerHTML=obtenerDatos();
            //limpiamos el formulario
            formulario.reset();
          }, 3000);

          
          
         
          
    }
}

function obtenerDatos(){
    let nombreApellidos = document.getElementById("nombreApellidos").value;
    let anyoNacimiento = document.getElementById("anyoNacimiento").value;
    let nivelEstudios = document.getElementsByName("nivelEstudios");
    let nivelEstudiosS;
    nivelEstudios.forEach((elemento)=>{
        if(elemento.checked){
            nivelEstudiosS = elemento.value;
        }
        
    });
    let password =document.getElementById("password").value;
    let tipoJornadas = ()=>{
        let jornadas = document.getElementsByName("tipoJornada");
        let jornadasS = "";
        jornadas.forEach((elemento)=>{
            if(elemento.checked){
                jornadasS += elemento.value +" ";
            }
        })
        return jornadasS;
    }

    return `
        <span>Nombre y Apellidos: ${nombreApellidos}</span><br>
        <span>Año de nacimiento: ${anyoNacimiento}</span><br>
        <span>Nivel de estudios: ${nivelEstudiosS}</span><br>
        <span>Contraseña: ${password}</span><br>
        <span>Tipo jornadas: ${tipoJornadas()}</span>
    `;
}