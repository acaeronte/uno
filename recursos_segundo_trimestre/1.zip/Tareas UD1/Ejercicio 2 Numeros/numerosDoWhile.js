let n = 1;
do{
    //compruebo que n es un numero impar
    if(n%2!=0){
        //es impar
        //compruebo que n no es multiplo ni de 7 ni de 3
        if(n%7!=0 && n%3!=0){
            console.log("El numero "+n+" no es multiplo de 3 ni de 7")
        }
    }
    //aumento el valor de n
    n++;
}while(n<=100)