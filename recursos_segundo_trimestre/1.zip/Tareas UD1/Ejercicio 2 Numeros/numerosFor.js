for(var n=1; n<=100; n++){
    if(n%2!=0){
        //es impar
        //compruebo que n no es multiplo ni de 7 ni de 3
        if(n%7!=0 && n%3!=0){
            console.log("El numero "+n+" no es multiplo de 3 ni de 7")
        }
    }
}