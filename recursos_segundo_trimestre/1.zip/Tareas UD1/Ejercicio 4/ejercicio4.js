let menu = "1. Área de triangulo\n2. Área de rectángulo\n3. Media aritmética de dos numeros\n4. Salir";
//este valor indica cuándo tiene que terminar el programa, continuará mientras terminado sea falso
let terminado = false;
do{
    //pido que seleccione una opcion
    let opt = prompt(menu, "");
    let optInt = parseInt(opt);
    //verifico que el valor ingresado es un entero
    if(Number.isInteger(optInt)){
        switch(optInt){
            case 1:
                //pido los datos
                let base = prompt("Introduce la longitud de la base del triangulo:");
                let altura = prompt("Introduce la longitud de la altura del triangulo:");
                let resultado1 = (base*altura)/2;
                alert("El resultado es: "+resultado1);
                console.log("El resultado es: "+resultado1);
                break;
            case 2:
                //pido los datos
                let l1 = prompt("Introduce la longitud del lado 1");
                let l2 = prompt("Introduce la longitud del lado 2");
                let resultado2 = l1*l2;
                alert("El resultado es: "+resultado2);
                console.log("El resultado es: "+resultado2);
                break;
            case 3:
                //pido los datos
                let n1 = parseInt(prompt("Introduce un numero:"),10);
                let n2 = parseInt(prompt("Introduce un numero:"),10);
                let resultado3 = (n1+n2)/2;
                alert("La media es: "+resultado3);
                console.log("La media es: "+resultado3);
                break;
            case 4:
                //se termina el programa
                console.log("Fin del ejercicio");
                //pongo a true la variable para que termine el bucle
                terminado = true;
                break;
            default:
                alert("Debe seleccionar una de las opciones disponibles");
                break;
                
        }
    }else{
        alert("Error, debe ser un numero");
    }
}while(!terminado)


// function pedirNumero(frase){
//     let esEntero = false;
//     var numero;
//     while(!esEntero){
//         let n = prompt(frase);
//         nInt = parseInt(n);
//         if(Number.isInteger(nInt)){
//             esEntero = true;
//             numero = nInt;
//         }else{
//             alert("Tienes que ingresar un número entero.");
//         }
//     }
//     return numero;
// }