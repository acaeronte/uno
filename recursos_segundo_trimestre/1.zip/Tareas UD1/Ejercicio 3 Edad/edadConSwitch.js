let edad = prompt("Introduce tu edad:", "");
edadInt = parseInt(edad, 10);
if(Number.isInteger(edadInt)){//comprubeo que es un numero entero
    //es un  numero entero
    //compruebo todas las condiciones
    switch(true){
        case (edad<18):
            alert("Eres menor de edad");
            break;
        case (edad >18 && edad<=30):
            alert("Eres muy joven");
            break;
        case (edad>30 && edad<=60):
            alert("Eres una persona adulta");
            break;
        case (edad>60):
            alert("Eres una persona adulta mayor");
            break;
    }

}else{//en caso contrario, emito un mensaje de error
    alert("Error, debe ser un numero");
}