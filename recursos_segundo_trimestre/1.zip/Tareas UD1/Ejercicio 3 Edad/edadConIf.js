let edad = prompt("Introduce tu edad:", "");
edadInt = parseInt(edad, 10);
if(Number.isInteger(edadInt)){//comprubeo que es un numero entero
    //es un  numero entero
    //Compruebo todas las condiciones
    if(edad<18){
        alert("Eres menor de edad");
    }else if(edad >18 && edad<=30){
        alert("Eres muy joven");
    }else if(edad>30 && edad<=60){
        alert("Eres una persona adulta");
    }else if(edad>60){
        alert("Eres una persona adulta mayor");
    }

}else{//en caso contrario, emito un mensaje de error
    alert("Error, debe ser un numero");
}