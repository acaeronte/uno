export class Grupo{
    #nomGrupo = "";
    #grupo = "";
    #nAlumnos = 0;
    #aAlumnos = [];
    constructor(nomGrupo, grupo, nAlumnos){
        this.#nomGrupo = this.#comprobarNomGrupo(nomGrupo);//metodo comprobar nombre de grupo
        this.#grupo = this.#comprobarGrupo(grupo);//metodo comprobar grupo
        this.#nAlumnos = this.#comprobarNAlumnos(nAlumnos);//metodo comprobar n alumnos
    }
    get nomGrupo(){
        return this.#nomGrupo;
    }
    get grupo(){
        return this.#grupo;
    }
    get nAlumnos(){
        return this.#nAlumnos;
    }
    get aAlumnos(){
        return this.#aAlumnos;
    }

    set nomGrupo(valor){
        this.#nomGrupo = this.#comprobarNomGrupo(valor);
    }
    set grupo(valor){
        this.#grupo = this.#comprobarGrupo(valor);
    }
    set nAlumnos(valor){
        this.#nAlumnos = this.#comprobarNAlumnos(valor);
    }

    altaAlumno(alumno){
        let indice = this.#aAlumnos.findIndex((persona)=> 
        persona.nomApe == alumno.nomApe && persona.fechaNac == alumno.fechaNac && persona.anioMatriculado == alumno.anioMatriculado && persona.foto == alumno.foto
        );
        if(indice==-1){//no existe, por lo que se introduce el alumno y se devuelve true
            this.#aAlumnos.push(alumno);
            return true;
        }else{
            return false;
        }
    }

    eliminarAlumno(nomApe){
        //si lo encontró entonces será eliminado, por lo que el valor será true
        let eliminado = this.#aAlumnos.some((elemento, indice)=>{
            if(elemento.nomApe==nomApe.toUpperCase()){
                //si el nombre es encontrado, lo elimina de la lista, y devuelve true
                this.#aAlumnos.splice(indice, 1);//elimino los "elementos" desde la posicion del indice, solo 1 elemento
                return true;
            }else{
                //en caso de que no lo encuentra, no lo eliminad por lo que devuelve false;
                return false;
            }
            
        });
        //devuelve el resultado de la operación
        return eliminado;
    }

    ordenarAlumnos(){
        this.#aAlumnos.sort((n1, n2)=>{
            if(n1.nomApe > n2.nomApe){
                return 1;
            }
            if(n1.nomApe<n2.nomApe){
                return -1;
            }
            return 0;
        });
    }

    toString(){
        return `${this.#nomGrupo} - ${this.#grupo} - nº Alumnos: ${this.#nAlumnos}`;
    }
    #comprobarNomGrupo(nombre){
        if(!isNaN(nombre)){
            throw "El nombre no puede estar vacío o ser un número.";
        }else{
            return nombre.charAt(0).toUpperCase() + nombre.slice(1).toLowerCase();
        }
    }

    #comprobarGrupo(grupo){
        if(!isNaN(grupo)){
            throw "El nombre no puede estar vacío o ser un número.";
        }
        if(grupo.length > 4){
            throw "El nombre abreviado del grupo no puede exceder 4 caracteres."
        }
        return grupo.toUpperCase();

    }

    #comprobarNAlumnos(nAlumnos){
        if(isNaN(nAlumnos)){
            throw "El valor tiene que ser un número."
        }
        if(nAlumnos <20 || nAlumnos>30){
            throw "El número de alumnos tiene que estar entre 20 y 30";
        }else{
            return nAlumnos;
        }
    }


}

