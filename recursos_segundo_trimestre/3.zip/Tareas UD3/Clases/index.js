import { Persona } from "./persona.js";
import { Profesor } from "./profesor.js";
import { Alumno } from "./alumno.js";
import { Centro } from "./centro.js";
import { Grupo } from "./grupo.js";

try{
let centro = new Centro("IES Trassierra", "Córdoba");
let grupos = crearGrupos();
let profesores = crearProfesores();
let alumnos = crearAlumnos();


//introduzco los alumnos en un grupo, 3 en uno y 3 en otro
alumnos.forEach((alumno, indice)=>{
    if(indice<3){
        
        grupos[0].altaAlumno(alumno);
    }else{
        grupos[1].altaAlumno(alumno);
    }
})
//ordeno los alumnos del primer grupo
grupos[0].ordenarAlumnos();

let eliminado = grupos[0].eliminarAlumno("Christopher Mendoza Chevez");
if(eliminado){
    console.log("Se ha eliminado a un alumno");
}else{
    console.log("xd")
}
//introduzcon los grupos dentro de aComunidad
grupos.forEach((grupo)=>{
    centro.addComunidad(grupo);
})

//introduzco los profesores dentro de aComunidad
profesores.forEach((profesor)=>{
    centro.addComunidad(profesor);
})
let contenido = "";
grupos.forEach((grupo)=>{
    contenido += `<tr><td>${grupo.toString()}</td></tr>`;
    grupo.aAlumnos.forEach((alumno)=>{
        contenido += `<tr><td><img width="25" height="25" src="./recursos/foto.jpg"/>${alumno.toString()}</td></tr>`;
    });
    
});
let profesoresTabla = "";
profesores.forEach((profesor)=>{
    profesoresTabla += `<tr><td>${profesor.toString()}</td></tr>`
})
let tabla =
`<table border = 1>
    <tr style ="text-align:center"><td>${centro.nombre}</td></tr>
    <tr><td>Grupos</td></tr>
    ${contenido}
    <tr><td>Profesores</td></tr>
    ${profesoresTabla}
</table>`;

document.body.innerHTML = tabla;

}catch(error){
    console.log(error);
}





function crearGrupos(){
    let grupo1 = new Grupo("2º curso desarrollo de aplicaciones web", "2DAW", 20);
    let grupo2 = new Grupo("2º curso desarrollo de aplicaciones multiplataforma","2DAM", 20);
    return [grupo1, grupo2];
}

function crearProfesores(){
    let profesor1 = new Profesor("Manuel Rodrigo Sánchez", "19/09/1980", "informática", 36);
    let profesor2 = new Profesor("Elena Puertas Sánchez", "19/07/1977", "mecánica", 25);
    let profesor3 = new Profesor("Miguel Gutierrez Sánchez", "19/05/1983", "electrónica", 15);
    return [profesor1, profesor2, profesor3];
}

function crearAlumnos(){
    let alumno1 = new Alumno("Christopher Mendoza Chevez", "15/04/2002", 2023, "foto.jpg");
    let alumno2 = new Alumno("Carlos Lora Gutierrez", "11/05/2003", 2023, "foto.jpg");
    let alumno3 = new Alumno("Maria Figueroa Higuera", "07/06/2004", 2023, "foto.jpg");

    let alumno4 = new Alumno("Marta Hidalgo Herrero", "06/07/2001", 2023, "foto.jpg");
    let alumno5 = new Alumno("Luis Casas Sanchez", "21/08/2000", 2023, "foto.jpg");
    let alumno6 = new Alumno("Luisa Cosano Jimenez", "30/09/2002", 2023, "foto.jpg");
    
    return [alumno1, alumno2, alumno3, alumno4, alumno5, alumno6];
}

