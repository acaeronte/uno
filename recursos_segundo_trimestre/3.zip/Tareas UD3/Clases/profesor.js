import { Persona } from "./persona.js";

export class Profesor extends Persona{
    #especialidad;
    #antiguedad;
    #especialidades = ["informática", "mecánica", "electrónica", "cocina", "madera"];
    constructor(nomApe, fechaNac, especialidad, antiguedad){
        super(nomApe, fechaNac);
        this.#especialidad = this.#comprobarEspecialidad(especialidad);//metodo de comprobar especialidad
        this.#antiguedad = this.#comprobarAntiguedad(antiguedad);//metodo de comprobar antiguedad
    }

    get especialidad(){
        return this.#especialidad;
    }
    get antiguedad(){
        return this.#antiguedad;
    }

    set especialidad(valor){
        this.#especialidad = this.#comprobarEspecialidad(valor);
    }
    set antiguedad(valor){
        this.#antiguedad = this.#comprobarAntiguedad(valor);
    }

    toString(){
        return super.toString()+`Especialidad: ${this.#especialidad}, antigüedad: ${this.#antiguedad}.`
    }

    #comprobarEspecialidad(especialidad){
        let valor = this.#especialidades.find((elemento)=>especialidad.toLowerCase()==elemento);
        if(valor){
            return valor;
        }else{
            throw "La especialidad introducida no coincide con ninguna registrada.";
        }
    }

    #comprobarAntiguedad(antiguedad){
        if(isNaN(antiguedad)){
            throw "La antigüedad debe ser un numero";
        }
        if(antiguedad < 1 || antiguedad > 35){
            return 35;
        }return antiguedad;
    }
}