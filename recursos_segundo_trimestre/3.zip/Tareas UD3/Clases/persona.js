export class Persona{
    #nomApe;
    #fechaNac;
    #fechaMinima = new Date("1963-01-01");//"01/01/1963"
    #fechaMaxima = new Date("2022-12-31");//"31/12/2022"

    constructor(nomApe, fechaNac){
        this.#nomApe = this.#comprobarNomApe(nomApe);//metodo comprobar nombre
        this.#fechaNac = this.#comprobarFechaNac(fechaNac);//metodo comprobar fecha
    }
    get nomApe(){
        return this.#nomApe;
    }
    get fechaNac(){
        return this.#fechaNac;
    }

    set nomApe(valor){
        this.#nomApe = this.#comprobarNomApe(valor);
    }

    set fechaNac(valor){
        this.#fechaNac = this.#comprobarFechaNac(valor);
    }
    toString(){
        return `${this.#nomApe}, fecha de nacimiento: ${this.#fechaNac}.`;
    }

    #comprobarNomApe(nombre){
        if(!isNaN(nombre)){
            throw "El nombre tiene que ser un string."
        }
        if(nombre.length<5){
            throw "El nombre debe tener al menos 5 caracteres";
        }
        return nombre.toUpperCase();
        
    }

    #comprobarFechaNac(fecha){
        //separo los valores de la fecha dia-mes-año
        let aFecha = fecha.split("/");
        //creo una nueva fecha a partir de esa informacion en formato año-mes-dia
        let dFecha = new Date(aFecha[2],aFecha[1], aFecha[0]);
        //comparo las fechas
        if(dFecha < this.#fechaMinima || dFecha > this.#fechaMaxima){
            throw "La fecha debe estar comprendida entre el 01 enero 1963 al 31 Diciembre 2022";
        }else{
            return fecha;
        }
    }
}