import { Persona } from "./persona.js";

export class Alumno extends Persona{
    #anioMatriculado;
    #foto;
    constructor(nomApe, fechaNac, anioMatriculado, foto){
        super(nomApe, fechaNac);
        this.#anioMatriculado = this.#comprobarAnioMatriculado(anioMatriculado);//metodo de comprobar año
        this.#foto = this.#comprobarFoto(foto);//metodo de comprobar foto
    }
    //Hacer getters y setters de año y foto
    get anioMatriculado(){
        return this.#anioMatriculado;
    }
    get foto(){
        return this.#foto;
    }

    set anioMatriculado(valor){
        this.#anioMatriculado = this.#comprobarAnioMatriculado(valor);
    }
    set foto(valor){
        this.#foto = this.#comprobarFoto(valor);
    }
    
    toString(){
        return super.toString()+`Año matriculado: ${this.#anioMatriculado}.`;
    }

    #comprobarAnioMatriculado(anyo){
        if(isNaN(anyo)){
            throw "El año debe ser un número";
        }
        if(anyo > new Date().getFullYear()){
            throw "El año de matriculación no puede exceder al año actual.";
        }
        return anyo;
    }

    #comprobarFoto(foto){
        if(!isNaN(foto)){
            throw "La foto debe ser un string.";
        }
        let extension = foto.slice(-3);
        if(extension!="jpg" && extension!="png"){
            //si es distinto no es valido
            throw "Solo se permiten extensiones jpg/png.";
        }return foto;
    }

}

