import { Grupo } from "./grupo.js";
import { Profesor } from "./profesor.js";
export class Centro{
    #nombre;
    #ciudad;
    #aComunidad = [[],[]];
    constructor(nombre, ciudad = "Córdoba"){
        this.#nombre = this.#comprobarValor(nombre);//metodo para verificar nombre
        this.#ciudad = this.#comprobarValor(ciudad);//metodo para verificar ciudad
    }

    get nombre(){
        return this.#nombre;
    }
    get ciudad(){
        return this.#ciudad;
    }
    get aComunidad(){
        return this.#aComunidad();
    }

    set nombre(valor){
        this.#nombre = this.#comprobarValor(valor);
    }

    set ciudad(valor){
        this.#ciudad = this.#comprobarValor(valor);
    }

    #comprobarValor(valor){
        if(!isNaN(valor)){
            throw "El valor no puede ser un número o estar vacío.";
        }
        return valor;

    }

    //grupo->0, profesor->1
    addComunidad(valor){
        if(valor instanceof(Grupo)){
            this.#aComunidad[0].push(valor);
        }else if(valor instanceof(Profesor)){
            this.#aComunidad[1].push(valor);
        }
    }

    toString(){
        
    }
}